// script.js
document.getElementById('verifyButton').addEventListener('click', function() {
    const buttonText = document.querySelector('.button-text');
    const loadingAnimation = document.getElementById('loadingAnimation');

    // Hide the button text
    buttonText.style.display = 'none';

    // Show the loading animation
    loadingAnimation.style.display = 'flex';

    // Simulate a delay for demonstration purposes
    setTimeout(() => {
        // Hide the loading animation and show the button text again (for demonstration purposes)
        loadingAnimation.style.display = 'none';
        buttonText.style.display = 'inline';
    }, 3000); // Change this timeout to the actual verification process duration
});